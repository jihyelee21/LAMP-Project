<?php
/**
 * Purpose: create a footer templates for all pages.
 * Authors : Hui, Debora, Jihye, Xiong, Jane
 * Date: Feb 8, 2019
 */
?>

<!--JS script goes here -->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" ></script>-->
<!--<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>-->
<script src="/lamp2project_group2/common/js/popper.min.js"></script>
<script src ="/lamp2project_group2/common/js/bootstrap.min.js"></script>
<script src="/lamp2project_group2/common/js/canvasjs.min.js"></script>
<script src="/lamp2project_group2/part_1/js/ResetAjax.js"></script>
<script src="/lamp2project_group2/part_2/js/send_to_editing_ajax.js"></script>
<script src="/lamp2project_group2/part_3/js/send_to_caculate.js"></script>
</body>
</html>


